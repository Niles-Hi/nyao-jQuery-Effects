$(document).ready(function() {
	$("#bars").click(function() {
		$("#popup").fadeToggle();
	});
	
	$("#hover-me").click(function() {
		$("#hover-me").fadeToggle();
	});
});